from make_kmeans_acc import make_kmeans_acc

external_data_width = 512
data_width = 16
dim = 2
c= 8
k = [c]

output_path = '/home/jeronimo/GIT/kmeans_examples/kmeans_k' + str(c) + '_d' + str(dim) + '/hw/rtl/acc0/'
#output_path = 'verilog'

make_kmeans_acc(external_data_width, data_width, k, dim, output_path)

